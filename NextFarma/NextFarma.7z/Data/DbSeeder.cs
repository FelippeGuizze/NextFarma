using NextFarma.Models;
using System;
using System.Linq;

namespace NextFarma.Data
{
    public static class DbSeeder
    {
        public static void Seed(AppDbContext context)
        {
            // Verifica se o banco j� tem dados
            if (context.CategoriasMedicamento.Any())
            {
                return; // O banco j� foi populado
            }

            // 1. Criar Categorias (Regras de Neg�cio Exatas)
            var categorias = new CategoriaMedicamento[]
            {
                new CategoriaMedicamento { Lista = "A1", Descricao = "Entorpecentes", TipoReceituario = "Notifica��o de Receita A", CorReceita = "Amarela" },
                new CategoriaMedicamento { Lista = "A2", Descricao = "Entorpecentes", TipoReceituario = "Notifica��o de Receita A", CorReceita = "Amarela" },
                new CategoriaMedicamento { Lista = "A3", Descricao = "Psicotr�picos", TipoReceituario = "Notifica��o de Receita A", CorReceita = "Amarela" },
                new CategoriaMedicamento { Lista = "B1", Descricao = "Psicotr�picos", TipoReceituario = "Receita de Controle Especial em duas vias", CorReceita = "Branca" },
                new CategoriaMedicamento { Lista = "B2", Descricao = "Psicotr�picos Anorex�genos", TipoReceituario = "Notifica��o de Receita B2", CorReceita = "Azul" },
                new CategoriaMedicamento { Lista = "C1", Descricao = "Outras Subst�ncias", TipoReceituario = "Receita de Controle Especial em duas vias", CorReceita = "Branca" },
                new CategoriaMedicamento { Lista = "C5", Descricao = "Anabolizantes", TipoReceituario = "Receita de Controle Especial em duas vias", CorReceita = "Branca" }
            };
            context.CategoriasMedicamento.AddRange(categorias);
            context.SaveChanges();

            // 2. Criar Medicamentos vinculados �s categorias
            var medicamentos = new Medicamento[]
            {
                new Medicamento { Nome = "Morfina", Concentracao = "10mg", Categoria = categorias.First(c => c.Lista == "A1") },
                new Medicamento { Nome = "Metadona", Concentracao = "5mg", Categoria = categorias.First(c => c.Lista == "A1") },
                new Medicamento { Nome = "Ritalina (Metilfenidato)", Concentracao = "10mg", Categoria = categorias.First(c => c.Lista == "A3") },
                new Medicamento { Nome = "Zolpidem", Concentracao = "10mg", Categoria = categorias.First(c => c.Lista == "B1") },
                new Medicamento { Nome = "Alprazolam", Concentracao = "0.5mg", Categoria = categorias.First(c => c.Lista == "B1") },
                new Medicamento { Nome = "Sibutramina", Concentracao = "15mg", Categoria = categorias.First(c => c.Lista == "B2") },
                new Medicamento { Nome = "Durateston", Concentracao = "250mg", Categoria = categorias.First(c => c.Lista == "C5") }
            };
            context.Medicamentos.AddRange(medicamentos);
            context.SaveChanges();

            // 3. Criar Pacientes Aleat�rios
            var pacientes = new Paciente[]
            {
                new Paciente { Nome = "Jo�o da Silva", Idade = 45, Endereco = "Rua das Flores, 123", CEP = "01001-000", RG = "12.345.678-9", Telefone = "(11) 99999-1111", Sexo = Sexo.Masculino },
                new Paciente { Nome = "Maria Oliveira", Idade = 32, Endereco = "Av. Paulista, 2000", CEP = "01310-200", RG = "98.765.432-1", Telefone = "(11) 98888-2222", Sexo = Sexo.Feminino },
                new Paciente { Nome = "Carlos Pereira", Idade = 60, Endereco = "Rua Augusta, 500", CEP = "01305-000", RG = "11.222.333-4", Telefone = "(11) 97777-3333", Sexo = Sexo.Masculino },
                new Paciente { Nome = "Ana Santos", Idade = 25, Endereco = "Rua Vergueiro, 100", CEP = "04101-000", RG = "55.666.777-8", Telefone = "(11) 96666-4444", Sexo = Sexo.Feminino }
            };
            context.Pacientes.AddRange(pacientes);
            context.SaveChanges();

            // 4. Criar Prontu�rios (Hist�rico) simulando prescri��es
            var rand = new Random();
            var prontuarios = new Prontuario[]
            {
                new Prontuario 
                { 
                    Paciente = pacientes[0], 
                    Medicamento = medicamentos.First(m => m.Nome == "Zolpidem"), 
                    CID = "F51.0", // Ins�nia
                    NumeroNotificacao = "SP" + rand.Next(100000, 999999),
                    DataEmissao = DateTime.Now.AddDays(-10), // Emitida h� 10 dias
                    TipoDeUso = TipoUso.Uso30Dias
                },
                new Prontuario 
                { 
                    Paciente = pacientes[1], 
                    Medicamento = medicamentos.First(m => m.Nome == "Sibutramina"), 
                    CID = "E66", // Obesidade
                    NumeroNotificacao = "SP" + rand.Next(100000, 999999),
                    DataEmissao = DateTime.Now.AddDays(-5),
                    TipoDeUso = TipoUso.Continuo
                },
                 new Prontuario 
                { 
                    Paciente = pacientes[2], 
                    Medicamento = medicamentos.First(m => m.Nome == "Morfina"), 
                    CID = "R52", // Dor Cr�nica
                    NumeroNotificacao = "SP" + rand.Next(100000, 999999),
                    DataEmissao = DateTime.Now.Date, // Hoje
                    TipoDeUso = TipoUso.Uso10Dias
                }
            };
            context.Prontuarios.AddRange(prontuarios);
            context.SaveChanges();
        }
    }
}